/* میرا مکتبہ — ضروری یادداشتیں
   ہر کتاب (اور ہر جلد) کی یادداشتیں: نمبر شمار خود، یادداشت، صفحہ نمبر، اور اصل صفحے کی تصویر (کیمرہ یا گیلری)۔
   متن ایپ کے ڈیٹا (db.notes) میں، تصاویر فون کے اندر IndexedDB میں رہتی ہیں (جگہ زیادہ، ایپ ہلکی)۔
   بھیجنا: ایک یادداشت، ایک جلد یا پوری کتاب — واٹس ایپ متن، پوسٹر تصویر یا PDF؛ اوپر مکتبے کا لیٹر ہیڈ۔ */
(() => {
  'use strict';
  const H = () => window.MA_APP;
  const K = () => window.MA_SHARE_UI && window.MA_SHARE_UI.kit;
  const $ = (r, s) => r.querySelector(s);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = n => (H() && H().num) ? H().num(n) : String(n);
  const toast = m => H() && H().toast(m);
  const ltr = s => '⁦' + s + '⁩';
  const notes = () => { const d = H().db(); d.notes = d.notes || []; return d.notes; };
  const vols = b => Math.max(1, parseInt(b.parts, 10) || 1);
  // 📁 موضوعات (ہیلپ ڈیسک #98): ایک عنوان کے حوالے — مختلف کتب / جلدوں سے — ایک فولڈر میں (n.topics = [موضوع کی شناخت])
  const topics = () => { const d = H().db(); d.topics = d.topics || []; return d.topics; };
  const bookOf = n => (H().db().books || []).find(x => x.id === n.book);
  const inTopic = (n, tid) => Array.isArray(n.topics) && n.topics.includes(tid);
  const topicNotes = tid => notes().filter(n => inTopic(n, tid)).sort((x, y) => (x.tord || x.ts || 0) - (y.tord || y.ts || 0));
  // فن کے مطابق اضافی کالم: تفسیر → سورہ، آیت؛ حدیث → رقم الحدیث
  const SURAS = 'الفاتحہ،البقرہ،آل عمران،النساء،المائدہ،الانعام،الاعراف،الانفال،التوبہ،یونس،ہود،یوسف،الرعد،ابراہیم،الحجر،النحل،بنی اسرائیل،الکہف،مریم،طٰہٰ،الانبیاء،الحج،المؤمنون،النور،الفرقان،الشعراء،النمل،القصص،العنکبوت،الروم،لقمان،السجدہ،الاحزاب،سبا،فاطر،یٰس،الصافات،ص،الزمر،المؤمن،حٰم السجدہ،الشوریٰ،الزخرف،الدخان،الجاثیہ،الاحقاف،محمد،الفتح،الحجرات،ق،الذاریات،الطور،النجم،القمر،الرحمٰن،الواقعہ،الحدید،المجادلہ،الحشر،الممتحنہ،الصف،الجمعہ،المنافقون،التغابن،الطلاق،التحریم،الملک،القلم،الحاقہ،المعارج،نوح،الجن،المزمل،المدثر،القیامہ،الدہر،المرسلات،النبا،النازعات،عبس،التکویر،الانفطار،المطففین،الانشقاق،البروج،الطارق،الاعلیٰ،الغاشیہ،الفجر،البلد،الشمس،اللیل،الضحیٰ،الانشراح،التین،العلق،القدر،البینہ،الزلزال،العادیات،القارعہ،التکاثر،العصر،الہمزہ،الفیل،قریش،الماعون،الکوثر،الکافرون،النصر،اللہب،الاخلاص،الفلق،الناس'.split('،');
  const isTafseer = b => b.cat === 'tafseer' || /^تفسیر/.test(((H().db().catNames || {})[b.cat]) || '');
  const isHadith = b => b.cat === 'hadith';
  const extraCols = b => isTafseer(b) ? [{ k: 'sura', t: 'سورہ', w: 58, pw: 170 }, { k: 'aya', t: 'آیت', w: 36, pw: 90 }] : isHadith(b) ? [{ k: 'hno', t: 'رقم الحدیث', w: 54, pw: 150 }] : [];
  const suraTxt = v => { const t = String(v || '').trim(); const n = parseInt(t, 10); return n >= 1 && n <= 114 && /^\d+$/.test(t) ? `${SURAS[n - 1]} (${n})` : t; };

  // ---------- تصاویر: IndexedDB ----------
  const IDB = 'maktaba-aziz-img', ST = 'img';
  let dbp = null;
  const idb = () => dbp || (dbp = new Promise((res, rej) => {
    const r = indexedDB.open(IDB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(ST);
    r.onsuccess = () => res(r.result); r.onerror = () => { dbp = null; rej(r.error); };
  }));
  async function tx(mode, fn) {
    const d = await idb();
    return new Promise((res, rej) => {
      const t = d.transaction(ST, mode), q = fn(t.objectStore(ST));
      t.oncomplete = () => res(q ? q.result : undefined); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
    });
  }
  const imgPut = (id, blob) => tx('readwrite', s => s.put(blob, id));
  const imgGet = id => tx('readonly', s => s.get(id)).catch(() => null);
  const imgDel = id => { delete urls[id]; return tx('readwrite', s => s.delete(id)).catch(() => {}); };
  const imgHas = async id => !!(await tx('readonly', s => s.count(id)).catch(() => 0));
  const urls = {};
  async function imgUrl(id) {
    if (urls[id]) return urls[id];
    const b = await imgGet(id); if (!b) return '';
    return (urls[id] = URL.createObjectURL(b));
  }
  const blobToData = b => new Promise(r => { const f = new FileReader(); f.onload = () => r(f.result); f.onerror = () => r(''); f.readAsDataURL(b); });
  const dataToBlob = u => { const [h, d] = String(u).split(','); const bin = atob(d); const a = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) a[i] = bin.charCodeAt(i); return new Blob([a], { type: (h.match(/:(.*?);/) || [])[1] || 'image/jpeg' }); };
  const loadImg = src => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });

  // تصویر: چھوٹی کریں، گھمائیں، اور «سکین» کی طرح صاف (روشنی اور کنٹراسٹ)
  async function processImage(src, rot = 0, clean = true) {
    const img = await loadImg(src);
    const max = 1280, r = Math.min(1, max / Math.max(img.width, img.height));
    const w = Math.round(img.width * r), h = Math.round(img.height * r);
    const sw = rot % 180 ? h : w, sh = rot % 180 ? w : h;
    const cv = document.createElement('canvas'); cv.width = sw; cv.height = sh;
    const ctx = cv.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, sw, sh);
    ctx.translate(sw / 2, sh / 2); ctx.rotate(rot * Math.PI / 180); ctx.drawImage(img, -w / 2, -h / 2, w, h);
    if (clean) {
      try {
        const id = ctx.getImageData(0, 0, sw, sh), p = id.data, hist = new Uint32Array(256);
        for (let i = 0; i < p.length; i += 16) hist[(p[i] * 77 + p[i + 1] * 150 + p[i + 2] * 29) >> 8]++;
        const tot = hist.reduce((s, x) => s + x, 0);
        let lo = 0, hi = 255, acc = 0;
        for (let i = 0; i < 256; i++) { acc += hist[i]; if (acc > tot * 0.02) { lo = i; break; } }
        acc = 0; for (let i = 255; i >= 0; i--) { acc += hist[i]; if (acc > tot * 0.04) { hi = i; break; } }
        if (hi - lo > 30) {
          const lut = new Uint8ClampedArray(256);
          for (let i = 0; i < 256; i++) { const v = (i - lo) / (hi - lo); lut[i] = 255 * Math.pow(Math.min(1, Math.max(0, v)), 1.1); }
          for (let i = 0; i < p.length; i += 4) { p[i] = lut[p[i]]; p[i + 1] = lut[p[i + 1]]; p[i + 2] = lut[p[i + 2]]; }
          ctx.putImageData(id, 0, 0);
        }
      } catch (e) {}
    }
    return new Promise(res => cv.toBlob(res, 'image/jpeg', 0.7));
  }

  // ---------- اسٹائل ----------
  const css = document.createElement('style');
  css.textContent = `
  .nt-go{width:100%;justify-content:center;margin-top:10px;font-size:20px;min-height:52px;border-radius:14px;
    background:linear-gradient(180deg,#2f8f6f,#14463a);border-color:#0e3a2f;box-shadow:0 4px 0 #0b2e26,0 8px 14px rgba(0,0,0,.18)}
  .nt-go b{font-weight:400;background:#e8c467;color:#14463a;border-radius:99px;padding:0 10px;font-size:16px}
  .nt-book{display:grid;gap:2px;text-align:center;padding:4px 0 8px}
  .nt-book b{font-family:var(--f-title);font-weight:400;font-size:28px;line-height:1.9;color:var(--accent)}
  .nt-book small{color:var(--muted);font-size:15px}
  .nt-vols{display:flex;gap:6px;overflow-x:auto;padding:4px 2px 8px;scrollbar-width:none}
  .nt-vols button{flex:none;border:1.5px solid var(--accent);background:var(--card);color:var(--accent);border-radius:99px;padding:0 14px;font:inherit;font-size:16px;line-height:2.1;cursor:pointer}
  .nt-vols button.on{background:var(--accent);color:#fff}
  .nt-vols button i{font-style:normal;font-size:13px;opacity:.85;margin-inline-start:4px}
  .nt-acts{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px}
  .nt-acts .btn{justify-content:center;font-size:17px;padding:0 10px}
  .nt-acts .nt-add{grid-column:1 / -1;font-size:20px;min-height:52px}
  .nt-sheet{border:1.5px solid var(--gilt);border-radius:14px;overflow:hidden;background:#fffdf6}
  .nt-hd,.nt-row{display:grid;grid-template-columns:34px minmax(0,1fr) 54px 64px;align-items:stretch}
  .nt-sheet.mv .nt-hd,.nt-sheet.mv .nt-row{grid-template-columns:34px minmax(0,1fr) 40px 50px 58px}
  .nt-sheet[style*="--ntc"] .nt-hd,.nt-sheet[style*="--ntc"] .nt-row{grid-template-columns:var(--ntc)}
  .nt-hd .xh{font-size:12.5px;line-height:1.5;display:grid;place-items:center}
  .nt-row .pg.x{font-size:13.5px;line-height:1.5}
  .nt-row .vl,.nt-row .pg{display:grid;place-items:center;text-align:center;font-size:17px;color:#14463a;font-variant-numeric:tabular-nums;cursor:pointer;border-inline-end:1px dashed #eadfc4;overflow-wrap:anywhere;line-height:1.3;padding:0 2px}
  .nt-flt{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:0 0 8px}
  .nt-flt label{display:flex;align-items:center;gap:6px;background:#e9f4ee;border:1.5px solid #1f6a54;border-radius:99px;padding:2px 4px 2px 10px}
  .nt-flt label span{font-size:14px;color:#14463a}
  .nt-flt select{border:0;background:#fff;border-radius:99px;font:inherit;font-size:15px;padding:2px 8px;color:#14463a;min-height:34px}
  .nt-rng{display:flex;align-items:center;gap:6px;flex-basis:100%;justify-content:center}
  .nt-rng input{border:1.5px solid #1f6a54;border-radius:10px;padding:2px 6px;font:14px Arial,sans-serif;min-height:34px}
  .nt-fnote{margin:-2px 0 8px;text-align:center;font-size:14px;color:#8a5f16}
  .nt-attgo{width:100%;border:1.5px dashed var(--gilt);background:var(--gilt-soft);color:#6b4a1a;border-radius:12px;font:inherit;font-size:16px;line-height:2.2;cursor:pointer}
  .nt-attgo small{font-size:13px;color:#8a7d62}
  .nt-hd{background:#14463a;color:#f1d27a;font-size:15px;line-height:2.2}
  .nt-hd span{text-align:center}
  .nt-row{border-top:1px solid #eadfc4;min-height:40px}
  .nt-row:nth-child(even){background-color:#fbf6e8}
  .nt-row .n{display:grid;place-items:center;color:var(--muted);font-size:14px;font-variant-numeric:tabular-nums}
  .nt-row .t{padding:2px 8px;font-size:16.5px;line-height:1.8;cursor:pointer;overflow-wrap:anywhere;border-inline:1px dashed #eadfc4;align-self:center}
  .nt-row .cl{display:flex;align-items:center;justify-content:center;gap:2px}
  .nt-row .cl .nt-th{width:28px;height:28px;border-width:1.5px}
  .nt-row .nt-sh svg{width:18px;height:18px}
  .nt-hd{font-size:14px !important;line-height:2 !important}
  .nt-clip{width:40px;height:40px;border-radius:10px;border:1.5px dashed var(--gilt);background:var(--gilt-soft);display:grid;place-items:center;cursor:pointer;padding:0;color:#8a5f16}
  .nt-th{width:40px;height:40px;border-radius:8px;object-fit:cover;border:2px solid #c8962f;cursor:pointer;display:block;background:#eee}
  .nt-sh{border:0;background:none;color:var(--accent);cursor:pointer;padding:2px;line-height:0}
  .nt-empty{padding:22px 14px;text-align:center;color:var(--muted);line-height:2}
  .nt-empty b{display:block;color:var(--fg);font-weight:400;font-size:19px}
  .nt-hint{font-size:14px;color:var(--muted);text-align:center;margin:8px 0 0;line-height:1.9}
  /* فارم */
  .nt-form textarea{width:100%;box-sizing:border-box;min-height:90px;border:1.5px solid var(--line);border-radius:12px;padding:8px 10px;font:inherit;font-size:19px;line-height:1.9;resize:vertical;background:#fff}
  .nt-form textarea:focus,.nt-form input:focus,.nt-form select:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft)}
  .nt-f2{display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .nt-f2 label,.nt-lb{display:grid;gap:2px;font-size:15px;color:var(--muted)}
  .nt-f2 input,.nt-f2 select{border:1.5px solid var(--line);border-radius:12px;min-height:46px;padding:0 10px;font:inherit;font-size:20px;background:#fff;width:100%;box-sizing:border-box}
  .nt-att{border:1.5px dashed var(--gilt);border-radius:14px;padding:10px;background:var(--gilt-soft);display:grid;gap:8px}
  .nt-att .row{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}
  .nt-att .btn{font-size:17px;padding:0 12px}
  .nt-prev{display:grid;gap:6px;justify-items:center}
  .nt-prev img{max-width:100%;max-height:260px;border-radius:10px;box-shadow:0 4px 14px rgba(0,0,0,.2);background:#fff}
  .nt-clean{display:flex;align-items:center;gap:6px;justify-content:center;font-size:15px;color:#6b4a1a}
  .nt-clean input{width:20px;height:20px;accent-color:#14463a}
  .nt-err{color:var(--danger);text-align:center;min-height:1.2em;margin:0;font-size:15px}
  .nt-del{color:var(--danger);border-color:var(--danger)}
  /* تصویر دیکھنا */
  .nt-view{position:fixed;inset:0;z-index:120;background:rgba(5,15,12,.96);display:grid;grid-template-rows:auto minmax(0,1fr) auto;direction:rtl}
  .nt-view .nt-vb{display:flex;align-items:center;gap:8px;padding:calc(8px + env(safe-area-inset-top)) 10px 8px;color:#f1d27a}
  .nt-view .nt-vb b{flex:1;font-weight:400;font-size:17px;line-height:1.8;color:#fff1c1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .nt-view .nt-vb button,.nt-view .ft button{border:1.5px solid #e8c467;background:rgba(255,255,255,.08);color:#fff1c1;border-radius:12px;min-height:42px;padding:0 12px;font:inherit;font-size:16px;cursor:pointer}
  .nt-view .sc{overflow:auto;display:grid;place-items:center;padding:6px;min-height:0}
  .nt-view .sc img{max-width:100%;max-height:calc(100dvh - 150px);object-fit:contain;transition:width .2s}
  .nt-view .sc.z{place-items:start center}
  .nt-view .sc.z img{max-width:none;max-height:none;width:200%}
  .nt-view .ft{display:flex;gap:8px;justify-content:center;align-items:center;padding:8px 10px calc(10px + env(safe-area-inset-bottom))}
  /* بھیجنے کا خانہ */
  .nt-so{display:grid;gap:10px}
  .nt-so .seg{display:flex;gap:6px;flex-wrap:wrap;justify-content:center}
  .nt-so .seg button{border:1.5px solid var(--accent);background:var(--card);color:var(--accent);border-radius:99px;padding:0 14px;font:inherit;font-size:16px;line-height:2.2;cursor:pointer}
  .nt-so .seg button.on{background:var(--accent);color:#fff}
  .nt-so .outs{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  .nt-so .outs .btn{justify-content:center;font-size:18px;min-height:52px}
  .nt-so .outs .btn.wide{grid-column:1 / -1}
  .nt-so .lb{font-size:15px;color:var(--muted);text-align:center;margin:0}
  /* 📁 موضوعات */
  .tp-pick{display:grid;gap:6px;font-size:15px;color:var(--muted)}
  /* MA1911TH164 (مالک کا حکم): موضوع سب سے اوپر — چنے ہوئے سامنے؛ تصویر چھوٹی؛ «محفوظ کریں» نیچے ہمیشہ نظر میں */
  .tp-pick.tp-top{background:#f3ead2;border:1.5px solid #c8962f;border-radius:14px;padding:8px 10px}
  .nt-form .nt-prev img{max-height:min(34vh,240px)}
  .nt-form > .btn.save{position:sticky;bottom:0;z-index:3;box-shadow:0 -6px 14px rgba(246,237,214,.95)}
  .tp-pick small{font-size:12.5px}
  .tp-chips{display:flex;flex-wrap:wrap;gap:6px}
  .tp-chips button{border:1.5px solid #8a5f16;background:#fff8e6;color:#6b4a1a;border-radius:99px;padding:0 12px;font:inherit;font-size:15px;line-height:2.1;cursor:pointer}
  .tp-chips button.on{background:#14463a;border-color:#14463a;color:#f1d27a}
  .tp-chips button.new{border-style:dashed;background:none}
  .tp-list{display:grid;gap:8px}
  .tp-f{display:grid;grid-template-columns:46px minmax(0,1fr) auto;gap:10px;align-items:center;text-decoration:none;color:var(--fg);background:#fffdf6;border:1.5px solid var(--gilt);border-radius:14px;padding:8px 12px;box-shadow:0 3px 0 #e4d6b0}
  .tp-f .ic{font-size:30px;line-height:1}
  .tp-f b{font-weight:400;font-size:19px;line-height:1.7;color:#14463a;display:block}
  .tp-f small{color:var(--muted);font-size:13.5px}
  .tp-f .c{background:#14463a;color:#f1d27a;border-radius:99px;padding:0 10px;font-size:15px;line-height:1.9}
  .tp-row{display:grid;grid-template-columns:30px minmax(0,1fr) auto;gap:8px;align-items:center;border-top:1px solid #eadfc4;padding:6px 8px;background:#fffdf6}
  .tp-row:nth-child(even){background:#fbf6e8}
  .tp-row .n{color:var(--muted);text-align:center;font-size:14px}
  .tp-row .t{font-size:16.5px;line-height:1.8;cursor:pointer;overflow-wrap:anywhere}
  .tp-row .r{display:block;font-size:13.5px;color:#8a5f16;line-height:1.7}
  .tp-row .cl{display:flex;gap:4px;align-items:center}
  .tp-row .x{border:0;background:none;color:var(--danger);font-size:17px;cursor:pointer;padding:2px 4px}
  .tp-pk{display:grid;gap:6px;max-height:55vh;overflow:auto}
  .tp-pk label{display:grid;grid-template-columns:26px minmax(0,1fr);gap:8px;align-items:start;border:1px solid #eadfc4;border-radius:10px;padding:6px 8px;background:#fff;font-size:16px;line-height:1.7}
  .tp-pk label input{width:20px;height:20px;accent-color:#14463a;margin-top:6px}
  .tp-pk small{display:block;color:#8a5f16;font-size:13px}
  `;
  document.head.appendChild(css);

  const I_CLIP = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5l-8.6 8.6a5.5 5.5 0 0 1-7.8-7.8l9.2-9.2a3.7 3.7 0 0 1 5.2 5.2l-9.2 9.2a1.8 1.8 0 0 1-2.6-2.6l8.5-8.5"/></svg>';
  const I_SHARE = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></svg>';

  // ---------- فہرست ----------
  const VKEY = 'maktaba-aziz-notes-vol';
  const volOf = {};   // ہر کتاب کی چنی ہوئی جلد
  try { Object.assign(volOf, JSON.parse(localStorage.getItem(VKEY) || '{}')); } catch (e) {}
  const saveVol = () => { try { localStorage.setItem(VKEY, JSON.stringify(volOf)); } catch (e) {} };
  const pnum = p => { const m = String(p || '').match(/\d+/); return m ? +m[0] : 1e9; };
  const sortN = (x, y) => (x.vol || 1) - (y.vol || 1) || pnum(x.page) - pnum(y.page) || (x.ts || 0) - (y.ts || 0);
  const allOf = b => notes().filter(n => n.book === b.id).sort(sortN);
  const listOf = (b, v) => allOf(b).filter(n => !v || (n.vol || 1) === v);
  const countOf = bookId => notes().filter(n => n.book === bookId).length;
  // فلٹر: جلد اور تاریخ (ہر کتاب کا الگ)
  const FL = {};
  const fOf = b => FL[b.id] || (FL[b.id] = { vol: 0, when: 'all', from: '', to: '', tp: '', sort: 'vol' });   // MA1911TH164: موضوع + ترتیب
  const pad2 = x => String(x).padStart(2, '0');
  const isoD = d => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
  const MONTHS = ['جنوری', 'فروری', 'مارچ', 'اپریل', 'مئی', 'جون', 'جولائی', 'اگست', 'ستمبر', 'اکتوبر', 'نومبر', 'دسمبر'];
  function inWhen(n, f) {
    if (f.when === 'all') return true;
    const d = new Date(n.ts || n.upd || 0), now = new Date();
    if (f.when === 'm0') return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
    if (f.when === 'm1') { const q = new Date(now.getFullYear(), now.getMonth() - 1, 1); return d.getFullYear() === q.getFullYear() && d.getMonth() === q.getMonth(); }
    if (f.when === 'y0') return d.getFullYear() === now.getFullYear();
    if (f.when === 'rng') { const t = isoD(d); return (!f.from || t >= f.from) && (!f.to || t <= f.to); }
    return true;
  }
  const SORTS = { vol: sortN, new: (x, y) => (y.ts || y.upd || 0) - (x.ts || x.upd || 0), old: (x, y) => (x.ts || x.upd || 0) - (y.ts || y.upd || 0) };
  const filtered = (b, f) => allOf(b).filter(n => (!f.vol || (n.vol || 1) === f.vol) && inWhen(n, f) && (!f.tp || (f.tp === '-' ? !(n.topics || []).length : inTopic(n, f.tp)))).sort(SORTS[f.sort] || sortN);
  function whenTxt(f) {
    const now = new Date();
    if (f.when === 'm0') return `${MONTHS[now.getMonth()]} ${now.getFullYear()}`;
    if (f.when === 'm1') { const q = new Date(now.getFullYear(), now.getMonth() - 1, 1); return `${MONTHS[q.getMonth()]} ${q.getFullYear()}`; }
    if (f.when === 'y0') return `سال ${now.getFullYear()}`;
    if (f.when === 'rng') { const dm = t => t ? t.split('-').reverse().join('/') : '…'; return `${dm(f.from)} سے ${dm(f.to)} تک`; }
    return '';
  }
  const fDesc = (b, f) => [vols(b) > 1 ? (f.vol ? `جلد ${f.vol}` : 'تمام جلدیں') : '', whenTxt(f), f.tp ? (f.tp === '-' ? 'بغیر موضوع' : '📁 ' + ((topics().find(t => t.id === f.tp) || {}).name || '')) : ''].filter(Boolean).join(' · ');

  let cur = null;   // { cat, b }
  let presetTopic = '';   // موضوع کے فولڈر سے نیا حوالہ — وہی موضوع پہلے سے چنا
  function page(cat, b) {
    cur = { cat, b };
    const V = vols(b), f = fOf(b), XC = extraCols(b);
    if (f.vol > V) f.vol = 0;
    const list = filtered(b, f), total = countOf(b.id);
    const view = H().view;
    view.innerHTML = `
      <section class="panel">
        <div class="panel-h"><a class="back" href="#/c/${cat.id}/b/${b.id}">→ کتاب</a><span class="crumb">${V > 1 ? 'حوالہ جات (انڈیکس)' : 'ضروری یادداشتیں'}</span></div>
        <div class="panel-b" id="ntb">
          <div class="nt-book"><b>${esc(b.name)}</b><small>${[b.author, V > 1 ? `${num(V)} جلدیں` : '', `${num(total)} حوالے`].filter(Boolean).map(esc).join(' · ')}</small></div>
          <div class="nt-flt">
            ${V > 1 ? `<label><span>جلد</span><select id="fVol"><option value="0">تمام جلدیں</option>${Array.from({ length: V }, (_, i) => `<option value="${i + 1}" ${f.vol === i + 1 ? 'selected' : ''}>جلد ${num(i + 1)}</option>`).join('')}</select></label>` : ''}
            <label><span>تاریخ</span><select id="fWhen">${[['all', 'سب'], ['m0', 'اس مہینے'], ['m1', 'پچھلے مہینے'], ['y0', 'اس سال'], ['rng', 'تاریخ سے تاریخ']].map(([k2, t]) => `<option value="${k2}" ${f.when === k2 ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
            ${(() => { const T = topics().filter(t => allOf(b).some(n => inTopic(n, t.id))); if (f.tp && f.tp !== '-' && !T.some(t => t.id === f.tp)) f.tp = '';
              return T.length ? `<label><span>📁 موضوع</span><select id="fTp"><option value="">سب موضوع</option>${T.map(t => `<option value="${t.id}" ${f.tp === t.id ? 'selected' : ''}>${esc(t.name)} (${num(allOf(b).filter(n => inTopic(n, t.id)).length)})</option>`).join('')}<option value="-" ${f.tp === '-' ? 'selected' : ''}>بغیر موضوع</option></select></label>` : ''; })()}
            <label><span>ترتیب</span><select id="fSort">${[['vol', V > 1 ? 'جلد و صفحہ وار' : 'صفحہ وار'], ['new', 'سب سے نئے پہلے'], ['old', 'سب سے پرانے پہلے']].map(([k2, t]) => `<option value="${k2}" ${f.sort === k2 ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
            ${f.when === 'rng' ? `<div class="nt-rng"><input type="date" id="fFrom" value="${f.from}"><span>تک</span><input type="date" id="fTo" value="${f.to}"></div>` : ''}
          </div>
          <div class="nt-acts">
            <button class="btn nt-add" type="button" data-a="add">＋ نیا حوالہ لکھیں</button>
            <button class="btn ghost" type="button" data-a="send">${I_SHARE} بھیجیں / PDF</button>
            <button class="btn ghost" type="button" data-a="blank">🖨️ خالی صفحہ</button>
          </div>
          ${(f.vol || f.when !== 'all' || f.tp) ? `<p class="nt-fnote">دکھائے جا رہے ہیں: ${num(list.length)} حوالے — ${esc(fDesc(b, f))}</p>` : ''}
          <div class="nt-sheet${V > 1 ? ' mv' : ''}"${XC.length ? ` style="--ntc:28px minmax(0,1fr) ${XC.map(c => c.w + 'px').join(' ')}${V > 1 ? ' 32px' : ''} 42px 36px"` : ''}>
            <div class="nt-hd"><span>نمبر</span><span>حوالہ / عبارت</span>${XC.map(c => `<span class="xh">${c.t}</span>`).join('')}${V > 1 ? '<span>جلد</span>' : ''}<span>صفحہ</span><span></span></div>
            ${list.length ? list.map((n, i) => `<div class="nt-row" data-id="${n.id}">
              <span class="n">${num(i + 1)}</span>
              <span class="t" data-a="edit">${esc(n.text)}</span>
              ${XC.map(c => `<span class="pg x" data-a="edit">${n[c.k] ? esc(c.k === 'sura' ? suraTxt(n[c.k]) : n[c.k]) : '—'}</span>`).join('')}
              ${V > 1 ? `<span class="vl" data-a="edit">${num(n.vol || 1)}</span>` : ''}
              <span class="pg" data-a="edit">${n.page ? esc(n.page) : '—'}</span>
              <span class="cl">${n.img ? `<img class="nt-th" data-a="view" data-img="${n.img}" alt="تصویر">` : ''}<button type="button" class="nt-sh" data-a="one" aria-label="بھیجیں">${I_SHARE}</button></span>
            </div>`).join('') : `<div class="nt-empty"><b>${total ? 'اس فلٹر میں کوئی حوالہ نہیں' : 'ابھی کوئی حوالہ نہیں'}</b>${total ? 'اوپر سے جلد یا تاریخ بدل کر دیکھیں۔' : '«نیا حوالہ لکھیں» دبائیں — عبارت، جلد نمبر اور صفحہ نمبر لکھیں۔ تصویر لگانا اختیاری ہے۔'}</div>`}
          </div>
          <p class="nt-hint">کسی سطر کو دبا کر ترمیم کریں</p>
        </div>
      </section>`;
    view.querySelectorAll('img[data-img]').forEach(async im => { const u = await imgUrl(im.dataset.img); if (u) im.src = u; else im.remove(); });
    const re = () => page(cat, b);
    $(view, '#fVol')?.addEventListener('change', e => { f.vol = +e.target.value; re(); });
    $(view, '#fWhen').addEventListener('change', e => { f.when = e.target.value; if (f.when === 'rng' && !f.from) { const d = new Date(); f.to = isoD(d); d.setDate(1); f.from = isoD(d); } re(); });
    $(view, '#fFrom')?.addEventListener('change', e => { f.from = e.target.value; re(); });
    $(view, '#fTp')?.addEventListener('change', e => { f.tp = e.target.value; re(); });
    $(view, '#fSort')?.addEventListener('change', e => { f.sort = e.target.value; re(); });
    $(view, '#fTo')?.addEventListener('change', e => { f.to = e.target.value; re(); });
    $(view, '#ntb').addEventListener('click', e => {
      const t = e.target.closest('[data-a]'); if (!t) return;
      const a = t.dataset.a, row = t.closest('.nt-row'), n = row ? notes().find(x => x.id === row.dataset.id) : null;
      if (a === 'add') openForm(b, null, f.vol || volOf[b.id] || 1);
      else if (a === 'send') openSend(b, { f: Object.assign({}, f) });
      else if (a === 'blank') blankPdf(b, f, t);
      else if (a === 'edit' && n) openForm(b, n);
      else if (a === 'view' && n) viewImg(b, n);
      else if (a === 'one' && n) openSend(b, { one: n });
    });
  }
  const refresh = () => { if (cur && /\/notes$/.test(location.hash)) page(cur.cat, cur.b); else if (/^#\/topics/.test(location.hash)) topicsRoute(); };

  // ---------- نئی / ترمیم ----------
  function openForm(b, n, vol) {
    const V = vols(b);
    let img = n ? (n.img || '') : '', fresh = null, rot = 0, clean = true, saved = false, srcUrl = '';
    const { wrap, close } = H().openSheet(n ? 'حوالے میں ترمیم' : 'نیا حوالہ', `
      <form class="sheet-b nt-form" id="ntForm" novalidate>
        <div class="tp-pick tp-top"><span>📁 موضوع / فولڈر <small>(اختیاری — ایک عنوان کے سب حوالے ایک جگہ)</small></span><div class="tp-chips" id="ntTops"></div></div>
        <label class="nt-lb">حوالہ / عبارت
          <textarea id="ntText" placeholder="مثلاً: جنگِ آزادی میں علمائے کرام کا کردار">${esc(n?.text || '')}</textarea></label>
        <div class="nt-f2">
          ${V > 1 ? `<label>جلد نمبر <small>(1 سے ${num(V)})</small><input id="ntVol" inputmode="numeric" autocomplete="off" dir="ltr" value="${n ? (n.vol || 1) : (vol || 1)}"></label>` : ''}
          <label>صفحہ نمبر<input id="ntPage" inputmode="numeric" autocomplete="off" dir="ltr" value="${esc(n?.page || '')}" placeholder="332"></label>
          ${isTafseer(b) ? `<label>سورہ <small>(نام یا نمبر)</small><input id="ntSura" list="ntSuras" autocomplete="off" value="${esc(n?.sura || '')}" placeholder="البقرہ"></label><label>آیت نمبر<input id="ntAya" inputmode="numeric" autocomplete="off" dir="ltr" value="${esc(n?.aya || '')}" placeholder="255"></label><datalist id="ntSuras">${SURAS.map((x, i) => `<option value="${x} (${i + 1})">`).join('')}</datalist>` : ''}
          ${isHadith(b) ? `<label>رقم الحدیث <small>(حدیث نمبر)</small><input id="ntHno" inputmode="numeric" autocomplete="off" dir="ltr" value="${esc(n?.hno || '')}" placeholder="1234"></label>` : ''}
        </div>
        <button type="button" class="nt-attgo" id="ntAttGo" ${n && n.img ? 'hidden' : ''}>📎 کتاب کے صفحے کی تصویر لگائیں <small>(اختیاری)</small></button>
        <div class="nt-att" id="ntAtt" ${n && n.img ? '' : 'hidden'}>
          <div class="nt-prev" id="ntPrev"></div>
          <div class="row">
            <button type="button" class="btn" data-p="cam">📷 کیمرے سے سکین</button>
            <button type="button" class="btn ghost" data-p="gal">🖼️ گیلری سے</button>
          </div>
          <input type="file" id="ntCam" accept="image/*" capture="environment" hidden>
          <input type="file" id="ntGal" accept="image/*" hidden>
        </div>
        <p class="nt-err" id="ntErr" role="alert"></p>
        <button class="btn save" type="submit">💾 ${n ? 'تبدیلی محفوظ کریں' : 'محفوظ کریں'}</button>
        ${n ? '<button class="btn ghost nt-del" type="button" id="ntDel">🗑️ یہ حوالہ حذف کریں</button>' : '<p class="hint center">محفوظ کرنے کے بعد اگلے حوالے کے لیے خانہ کھلا رہے گا</p>'}
      </form>`, () => { if (srcUrl) URL.revokeObjectURL(srcUrl); if (saved) refresh(); });
    const prev = $(wrap, '#ntPrev'), err = $(wrap, '#ntErr');
    let tsel = new Set(n && Array.isArray(n.topics) ? n.topics : (presetTopic ? [presetTopic] : []));
    const drawTops = () => { $(wrap, '#ntTops').innerHTML = topics().map(t => `<button type="button" class="${tsel.has(t.id) ? 'on' : ''}" data-tp="${t.id}">${tsel.has(t.id) ? '✓ ' : ''}${esc(t.name)}</button>`).join('') + '<button type="button" class="new" data-tp="+">＋ نیا موضوع</button>'; };
    drawTops();
    $(wrap, '#ntTops').addEventListener('click', e => {
      const t = e.target.closest('[data-tp]'); if (!t) return;
      if (t.dataset.tp === '+') { const nt = newTopic(); if (nt) { tsel.add(nt.id); drawTops(); } return; }
      tsel.has(t.dataset.tp) ? tsel.delete(t.dataset.tp) : tsel.add(t.dataset.tp); drawTops();
    });
    $(wrap, '#ntAttGo').onclick = () => { $(wrap, '#ntAtt').hidden = false; $(wrap, '#ntAttGo').hidden = true; };
    async function drawPrev() {
      if (fresh) {
        prev.innerHTML = `<img src="${URL.createObjectURL(fresh)}" alt="">
          <div class="row" style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center"><button type="button" class="btn ghost small" data-p="rot">↻ گھمائیں</button><button type="button" class="btn ghost small" data-p="rm">✕ ہٹائیں</button></div>
          <label class="nt-clean"><input type="checkbox" id="ntClean" ${clean ? 'checked' : ''}> صفحہ صاف کریں (سکین جیسا)</label>`;
        $(prev, '#ntClean').onchange = async e => { clean = e.target.checked; await rebuild(); };
      } else if (img) {
        const u = await imgUrl(img);
        prev.innerHTML = u ? `<img src="${u}" alt=""><div class="row" style="display:flex;gap:8px;justify-content:center"><button type="button" class="btn ghost small" data-p="rm">✕ تصویر ہٹائیں</button></div>` : '';
      } else prev.innerHTML = `<span style="color:#8a5f16;font-size:15px;text-align:center;line-height:1.9">📎 کتاب کے اس صفحے کی تصویر لگائیں جہاں یہ مضمون لکھا ہے</span>`;
    }
    async function rebuild() { if (!srcUrl) return; prev.innerHTML = '<span>تصویر تیار ہو رہی ہے…</span>'; try { fresh = await processImage(srcUrl, rot, clean); } catch (e) { err.textContent = 'یہ تصویر نہیں کھل سکی'; fresh = null; } drawPrev(); }
    drawPrev();
    const pick = async f => {
      if (!f) return;
      if (srcUrl) URL.revokeObjectURL(srcUrl);
      srcUrl = URL.createObjectURL(f); rot = 0; await rebuild();
    };
    $(wrap, '#ntCam').onchange = e => { pick(e.target.files[0]); e.target.value = ''; };
    $(wrap, '#ntGal').onchange = e => { pick(e.target.files[0]); e.target.value = ''; };
    wrap.addEventListener('click', e => {
      const p = e.target.closest('[data-p]')?.dataset.p; if (!p) return;
      if (p === 'cam') $(wrap, '#ntCam').click();
      if (p === 'gal') $(wrap, '#ntGal').click();
      if (p === 'rot') { rot = (rot + 90) % 360; rebuild(); }
      if (p === 'rm') { fresh = null; img = ''; if (srcUrl) { URL.revokeObjectURL(srcUrl); srcUrl = ''; } drawPrev(); }
    });
    $(wrap, '#ntDel')?.addEventListener('click', async () => {
      if (!confirm('یہ حوالہ حذف کریں؟')) return;
      const L = notes(), i = L.findIndex(x => x.id === n.id);
      if (i > -1) { if (L[i].img) await imgDel(L[i].img); L.splice(i, 1); H().save(); }
      saved = true; close(); toast('یادداشت حذف ہو گئی');
    });
    setTimeout(() => $(wrap, '#ntText').focus(), 60);
    $(wrap, '#ntForm').addEventListener('submit', async e => {
      e.preventDefault();
      const text = $(wrap, '#ntText').value.trim(), pg = String($(wrap, '#ntPage').value).trim();
      const v = V > 1 ? parseInt(String($(wrap, '#ntVol').value).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)), 10) : 1;
      if (!text) { err.textContent = 'حوالہ / عبارت لکھنا ضروری ہے'; $(wrap, '#ntText').focus(); return; }
      if (V > 1 && !(v >= 1 && v <= V)) { err.textContent = `جلد نمبر 1 سے ${V} تک لکھیں`; $(wrap, '#ntVol').focus(); return; }
      let imgId = img;
      if (fresh) {
        imgId = H().newId();
        try { await imgPut(imgId, fresh); } catch (x) { err.textContent = 'تصویر محفوظ نہیں ہو سکی — فون میں جگہ دیکھیں'; return; }
      }
      const old = n && n.img && n.img !== imgId ? n.img : '';
      const xv = {}; [['sura', '#ntSura'], ['aya', '#ntAya'], ['hno', '#ntHno']].forEach(([kk, sel]) => { const el = $(wrap, sel); if (el) xv[kk] = String(el.value).trim(); });
      xv.topics = [...tsel].filter(id => topics().some(t => t.id === id));
      if (n) Object.assign(n, { text, page: pg, vol: v, img: imgId, upd: Date.now() }, xv);
      else notes().push(Object.assign({ id: H().newId(), book: b.id, vol: v, text, page: pg, img: imgId, ts: Date.now() }, xv));
      if (old) await imgDel(old);
      H().save(); saved = true;
      if (n) { close(); toast('تبدیلی محفوظ ہو گئی'); if (/^#\/topics/.test(location.hash)) topicsRoute(); return; }
      volOf[b.id] = v; saveVol();
      toast(`حوالہ محفوظ — کل ${num(countOf(b.id))} — اگلا لکھیں`);
      $(wrap, '#ntText').value = ''; $(wrap, '#ntPage').value = ''; ['#ntAya', '#ntHno'].forEach(sel => { const el = $(wrap, sel); if (el) el.value = ''; }); fresh = null; img = ''; if (srcUrl) { URL.revokeObjectURL(srcUrl); srcUrl = ''; } err.textContent = '';
      $(wrap, '#ntAtt').hidden = true; $(wrap, '#ntAttGo').hidden = false;
      drawPrev(); refresh(); $(wrap, '#ntText').focus();
    });
  }

  // 📎 سیدھا تصویر لگانا (فہرست سے)
  function quickAttach(b, n) {
    const { wrap, close } = H().openSheet('صفحے کی تصویر لگائیں', `
      <div class="sheet-b nt-form">
        <p class="hint center" style="margin:0">${esc(n.text)}${n.page ? ` — صفحہ ${num(n.page)}` : ''}</p>
        <div class="nt-att"><div class="row">
          <button type="button" class="btn" data-p="cam">📷 کیمرے سے سکین</button>
          <button type="button" class="btn ghost" data-p="gal">🖼️ گیلری سے</button></div></div>
        <input type="file" id="qaCam" accept="image/*" capture="environment" hidden><input type="file" id="qaGal" accept="image/*" hidden>
      </div>`);
    const go = async f => {
      if (!f) return;
      const u = URL.createObjectURL(f);
      try {
        const blob = await processImage(u, 0, true), id = H().newId();
        await imgPut(id, blob);
        if (n.img) await imgDel(n.img);
        n.img = id; n.upd = Date.now(); H().save(); close(); toast('تصویر لگ گئی'); refresh();
        openForm(b, n);   // گھمانا / صاف کرنا ہو تو یہیں
      } catch (e) { toast('تصویر محفوظ نہیں ہو سکی'); }
      finally { URL.revokeObjectURL(u); }
    };
    wrap.addEventListener('click', e => { const p = e.target.closest('[data-p]')?.dataset.p; if (p === 'cam') $(wrap, '#qaCam').click(); if (p === 'gal') $(wrap, '#qaGal').click(); });
    $(wrap, '#qaCam').onchange = e => go(e.target.files[0]);
    $(wrap, '#qaGal').onchange = e => go(e.target.files[0]);
  }

  // ---------- تصویر بڑی دیکھیں ----------
  async function viewImg(b, n) {
    const u = await imgUrl(n.img); if (!u) return;
    const w = document.createElement('div'); w.className = 'nt-view';
    w.innerHTML = `<div class="nt-vb"><b>${esc(n.text)}${n.page ? ` — صفحہ ${num(n.page)}` : ''}</b><button type="button" data-x="close">✕ بند</button></div>
      <div class="sc" id="ntSc"><img src="${u}" alt=""></div>
      <div class="ft"><button type="button" data-x="zoom">🔍 بڑا / چھوٹا</button><button type="button" data-x="send">${I_SHARE} بھیجیں</button><button type="button" data-x="edit">✏️ ترمیم</button></div>`;
    document.body.appendChild(w);
    const onBack = () => w.remove();
    w.addEventListener('click', e => {
      const x = e.target.closest('[data-x]')?.dataset.x;
      if (x === 'close') w.remove();
      if (x === 'zoom') $(w, '#ntSc').classList.toggle('z');
      if (x === 'send') { w.remove(); openSend(b, { one: n }); }
      if (x === 'edit') { w.remove(); openForm(b, n); }
    });
    window.addEventListener('hashchange', onBack, { once: true });
  }

  // ---------- بھیجنا ----------
  const bookLine = b => [b.name, b.author].filter(Boolean).join(' — ');
  function scopeList(b, o) {
    if (o.one) return [o.one];
    if (o.list) return o.list;
    return filtered(b, o.f || { vol: 0, when: 'all' });
  }
  function scopeTitle(b, o) {
    if (o.one) return 'حوالہ';
    if (b.topic) return `موضوع: ${b.name}`;
    const d = fDesc(b, o.f || { vol: 0, when: 'all' });
    return 'حوالہ جات / ضروری یادداشتیں' + (d && (o.f && (o.f.vol || o.f.when !== 'all')) ? ` — ${d}` : '');
  }
  const refLine = (b, n) => b.topic ? topicRef(n) : [n.sura ? `سورہ ${suraTxt(n.sura)}` : '', n.aya ? `آیت ${n.aya}` : '', n.hno ? `رقم الحدیث ${n.hno}` : '', vols(b) > 1 ? `جلد ${n.vol || 1}` : '', n.page ? `صفحہ ${n.page}` : ''].filter(Boolean).join('، ');
  // موضوع کے فولڈر میں ہر حوالے کے ساتھ کتاب کا نام
  function topicRef(n, noPage) {
    const bk = bookOf(n); if (!bk) return '';
    return [bk.name, n.sura ? `سورہ ${suraTxt(n.sura)}` : '', n.aya ? `آیت ${n.aya}` : '', n.hno ? `رقم الحدیث ${n.hno}` : '', vols(bk) > 1 ? `جلد ${n.vol || 1}` : '', !noPage && n.page ? `صفحہ ${n.page}` : ''].filter(Boolean).join('، ');
  }
  function textOf(b, o) {
    const k = K(), L = scopeList(b, o);
    let t = (k && k.brandText ? k.brandText() + '\n' : '') + `*${scopeTitle(b, o)}*\n${b.topic ? `📁 ${L.length} حوالے` : `📖 ${bookLine(b)}`}\n\n`;
    L.forEach((n, i) => { const r = refLine(b, n); t += `${o.one ? '' : (i + 1) + ') '}${n.text}${r ? ` — (${r})` : ''}\n`; });
    return t.trim();
  }

  function openSend(b, o0) {
    const V = vols(b);
    const o = Object.assign({ f: { vol: 0, when: 'all' }, imgs: false }, o0);
    const L0 = o.one ? [o.one] : null;
    const { wrap, close } = H().openSheet(o.one ? 'حوالہ بھیجیں' : 'حوالہ جات بھیجیں', `
      <div class="sheet-b nt-so" id="ntSo"></div>`);
    const box = $(wrap, '#ntSo');
    const draw = () => {
      const L = L0 || scopeList(b, o), withImg = L.filter(n => n.img).length;
      box.innerHTML = `
        <p class="lb">${o.one ? esc(o.one.text) : `${num(L.length)} حوالے${fDesc(b, o.f) ? ` — ${esc(fDesc(b, o.f))}` : ''}`}${withImg ? ` · ${num(withImg)} تصاویر` : ''}</p>
        ${!o.one && !b.topic ? '<p class="lb" style="font-size:13px">جلد یا تاریخ کے حساب سے چھانٹنا ہو تو پچھلے صفحے پر اوپر سے فلٹر چنیں</p>' : ''}
        ${withImg ? `<div class="seg" data-g="im"><button type="button" data-i="1" class="${o.imgs ? 'on' : ''}">تصاویر کے ساتھ</button><button type="button" data-i="0" class="${o.imgs ? '' : 'on'}">صرف فہرست</button></div>` : ''}
        <div class="outs">
          <button class="btn" type="button" data-o="wa">واٹس ایپ</button>
          <button class="btn" type="button" data-o="img">🖼️ پوسٹر تصویر</button>
          <button class="btn" type="button" data-o="pdf">📄 PDF / پرنٹ</button>
          <button class="btn ghost" type="button" data-o="copy">📋 کاپی</button>
        </div>
        ${L.length ? '' : '<p class="nt-err">اس میں کوئی حوالہ نہیں</p>'}`;
      box.querySelectorAll('.outs .btn').forEach(x => { x.disabled = !L.length; });
    };
    draw();
    box.addEventListener('click', async e => {
      const s = e.target.closest('[data-s]'), im = e.target.closest('[data-i]'), out = e.target.closest('[data-o]');
      if (im) { o.imgs = im.dataset.i === '1'; draw(); return; }
      if (!out) return;
      const k = K(); if (!k) return;
      const kind = out.dataset.o, txt = textOf(b, o), old = out.innerHTML;
      try {
        if (kind === 'copy') { toast(await k.copyText(txt) ? 'کاپی ہو گئی' : 'کاپی نہیں ہو سکی'); return; }
        if (kind === 'wa') {
          // ایک یادداشت + تصویر: تصویر اور متن اکٹھے
          if (o.one && o.one.img && navigator.canShare) {
            const blob = await imgGet(o.one.img);
            if (blob) { const f = new File([blob], `safha-${o.one.page || 'x'}.jpg`, { type: 'image/jpeg' }); if (navigator.canShare({ files: [f] })) { try { await navigator.share({ files: [f], text: txt }); return; } catch (x) { if (x.name === 'AbortError') return; } } }
          }
          // MA1911TH164 (مالک کا حکم): پورا موضوع / فہرست — سب اصل صفحات کی تصاویر + متن ایک ساتھ واٹس ایپ پر
          if (!o.one && o.imgs && navigator.canShare) {
            const LL = scopeList(b, o).filter(n => n.img).slice(0, 40), files = [];
            out.disabled = true; out.textContent = 'تصاویر تیار…';
            for (let i = 0; i < LL.length; i++) { const n = LL[i]; try { const blob = await imgGet(n.img); if (blob) { const bk = bookOf(n); files.push(new File([blob], `${i + 1}-${String((bk && bk.name) || 'kitab').replace(/[^\w\u0600-\u06FF]+/g, '-').slice(0, 30)}-j${n.vol || 1}-s${n.page || 'x'}.jpg`, { type: blob.type || 'image/jpeg' })); } } catch (_) {} }
            out.disabled = false; out.innerHTML = old;
            if (files.length && navigator.canShare({ files })) { try { await navigator.share({ files, text: txt }); return; } catch (x) { if (x && x.name === 'AbortError') return; } }
          }
          if (txt.length <= 3500) location.href = 'https://wa.me/?text=' + encodeURIComponent(txt);
          else if (navigator.share) navigator.share({ text: txt }).catch(() => {});
          else { await k.copyText(txt); toast('کاپی ہو گئی — واٹس ایپ میں پیسٹ کریں'); }
          return;
        }
        out.disabled = true; out.textContent = 'بن رہا ہے…';
        const stamp = new Date().toISOString().slice(0, 10);
        if (kind === 'img') await k.deliver(await render(b, o, 'poster'), `yaddashtain-${stamp}.png`, scopeTitle(b, o));
        if (kind === 'pdf') await k.deliver(await render(b, o, 'pdf'), `yaddashtain-${stamp}.pdf`, scopeTitle(b, o));
      } catch (x) {
        console.warn(x);
        toast(x && x.message === 'long' ? 'تصویر کے لیے بہت لمبی ہے — PDF بنائیں' : 'فائل نہیں بن سکی، دوبارہ کوشش کریں');
      } finally { out.disabled = false; out.innerHTML = old; }
    });
  }

  // ---------- کینوس: پوسٹر اور PDF ----------
  const W = 1240, M = 80, PH = 1754, TOP = 74, BOT = 118;   // A4 — فریم کے اندر
  const C = { green: '#14463a', gold: '#c8962f', gold2: '#e8c467', line: '#e4d6b0', fg: '#2b2620', muted: '#7d7262', alt: '#fbf6e8', paper: '#fffdf6' };
  const COLS = { n: 90, pg: 170 };
  function wrapLines(ctx, text, w) {
    const out = []; String(text || '').split(/\n/).forEach(par => {
      let line = '';
      par.split(/\s+/).filter(Boolean).forEach(word => {
        const t = line ? line + ' ' + word : word;
        if (ctx.measureText(t).width <= w || !line) line = t; else { out.push(line); line = word; }
      });
      out.push(line);
    });
    return out.filter((l, i) => l || i === 0);
  }
  async function render(b, o, mode, blankRows) {
    const k = K(); await k.ready();
    const FONT = k.FONT, V = vols(b);
    const L = blankRows ? [] : scopeList(b, o);
    const meas = document.createElement('canvas').getContext('2d');
    const FS = 26, LH = 42;
    const CN = 80, CV = V > 1 ? 110 : 0, CP = 130, XC = extraCols(b), CE = XC.reduce((a, c) => a + c.pw, 0);
    const tw = W - 2 * M - CN - CV - CP - CE - 24;
    // اضافی کالم: بائیں سے — صفحہ، جلد، پھر (آیت، سورہ)، پھر عبارت
    let xe = M + CP + CV; const XP = XC.slice().reverse().map(c => { const o = { c, x0: xe, xc: xe + c.pw / 2 }; xe += c.pw; return o; });
    const xN = W - M - CN / 2, xT = W - M - CN - 12, xV = M + CP + CV / 2, xP = M + CP / 2;
    const blocks = [];
    blocks.push({ h: k.letterH(), draw: (ctx, y) => k.letterDraw(ctx, y) });
    const ttl = blankRows ? 'حوالہ جات / ضروری یادداشتیں' : scopeTitle(b, o);
    blocks.push({ h: 116, draw: (ctx, y) => k.titleDraw(ctx, y, ttl, b.topic ? `${new Set(L.map(n => n.book)).size} کتب سے` : `کتاب: ${k.fit(meas, b.name, 420)}`, blankRows ? (V > 1 ? `${V} جلدیں` : '') : `کل ${L.length} حوالے`) });
    const head = { h: 54, keep: 1, draw(ctx, y) {
      ctx.fillStyle = C.green; k.roundRect(ctx, M, y + 6, W - 2 * M, 46, 8); ctx.fill();
      ctx.fillStyle = C.gold2; ctx.font = `22px ${FONT}`; ctx.textAlign = 'center';
      ctx.fillText('نمبر', xN, y + 38); ctx.fillText('صفحہ', xP, y + 38); if (CV) ctx.fillText('جلد', xV, y + 38);
      XP.forEach(o => ctx.fillText(o.c.t, o.xc, y + 38));
      ctx.fillText('حوالہ / عبارت', M + CP + CV + CE + tw / 2 + 12, y + 38);
    } };
    const row = (i, n, alt) => {
      meas.font = `${FS}px ${FONT}`;
      const lines = n ? wrapLines(meas, n.text, tw) : [''];
      const rl = n && b.topic ? wrapLines(meas, '📖 ' + topicRef(n, true), tw) : [];
      const h = Math.max(52, (lines.length + rl.length) * LH + 12);
      return { h, tbl: true, draw(ctx, y) {
        ctx.fillStyle = alt ? C.alt : C.paper; ctx.fillRect(M, y, W - 2 * M, h);
        ctx.strokeStyle = C.line; ctx.lineWidth = 1.2;
        ctx.beginPath(); ctx.moveTo(M, y + h - .5); ctx.lineTo(W - M, y + h - .5);
        ctx.moveTo(W - M - CN, y); ctx.lineTo(W - M - CN, y + h);
        ctx.moveTo(M + CP, y); ctx.lineTo(M + CP, y + h);
        if (CV) { ctx.moveTo(M + CP + CV, y); ctx.lineTo(M + CP + CV, y + h); }
        XP.forEach(o => { ctx.moveTo(o.x0 + o.c.pw, y); ctx.lineTo(o.x0 + o.c.pw, y + h); });
        ctx.stroke();
        ctx.strokeStyle = C.gold; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(M, y); ctx.lineTo(M, y + h); ctx.moveTo(W - M, y); ctx.lineTo(W - M, y + h); ctx.stroke();
        if (!n) return;
        const by = y + 34;
        ctx.textAlign = 'center'; ctx.fillStyle = C.muted; ctx.font = `22px ${FONT}`; ctx.fillText(String(i), xN, by);
        ctx.fillStyle = C.green; ctx.font = `${FS}px ${FONT}`; ctx.fillText(n.page ? String(n.page) : '—', xP, by);
        if (CV) ctx.fillText(String(n.vol || 1), xV, by);
        XP.forEach(o => { const val = n[o.c.k] ? (o.c.k === 'sura' ? suraTxt(n[o.c.k]) : String(n[o.c.k])) : '—'; ctx.font = `${o.c.k === 'sura' ? 22 : FS}px ${FONT}`; ctx.fillText(k.fit(ctx, val, o.c.pw - 14), o.xc, by); });
        ctx.font = `${FS}px ${FONT}`;
        ctx.textAlign = 'right'; ctx.fillStyle = C.fg; ctx.font = `${FS}px ${FONT}`;
        lines.forEach((l, jj) => ctx.fillText(l, xT, by + jj * LH));
        if (rl.length) { ctx.fillStyle = '#8a5f16'; ctx.font = `${FS - 3}px ${FONT}`; rl.forEach((l, jj) => ctx.fillText(l, xT, by + (lines.length + jj) * LH)); }
      } };
    };
    blocks.push(head);
    L.forEach((n, jj) => blocks.push(row(jj + 1, n, jj % 2)));
    // نیچے کی پٹی: پرنٹ کے لیے خالی سطریں (صفحہ بھرنے تک)
    blocks.push({ fill: mode === 'pdf', h: 20, draw() {} });
    // تصاویر
    const pics = (o.imgs && !blankRows) ? L.filter(n => n.img) : [];
    const loaded = [];
    for (const n of pics) { const u = await imgUrl(n.img); if (!u) continue; try { loaded.push({ n, im: await loadImg(u) }); } catch (e) {} }
    if (loaded.length) {
      blocks.push({ h: 90, page: mode === 'pdf', draw(ctx, y) {
        ctx.fillStyle = C.green; ctx.font = `34px ${FONT}`; ctx.textAlign = 'center'; ctx.fillText('اصل صفحات کی تصاویر', W / 2, y + 56);
        ctx.strokeStyle = C.gold; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(W / 2 - 180, y + 74); ctx.lineTo(W / 2 + 180, y + 74); ctx.stroke();
      } });
      loaded.forEach(({ n, im }) => {
        const maxH = mode === 'pdf' ? PH - TOP - BOT - 90 - 110 : 1700;
        let w = W - 2 * M - 20, h = im.height * w / im.width; if (h > maxH) { h = maxH; w = im.width * h / im.height; }
        const idx = L.indexOf(n) + 1, rr = refLine(b, n);
        const cap = `${idx}) ${n.text}${rr ? ` — (${rr})` : ''}`;
        blocks.push({ h: 70 + h + 40, draw(ctx, y) {
          ctx.fillStyle = '#efe2bf'; k.roundRect(ctx, M, y + 8, W - 2 * M, 54, 10); ctx.fill();
          ctx.fillStyle = C.green; ctx.font = `26px ${FONT}`; ctx.textAlign = 'right'; ctx.fillText(k.fit(ctx, cap, W - 2 * M - 40), W - M - 20, y + 44);
          const x = (W - w) / 2, yy = y + 72;
          ctx.fillStyle = 'rgba(0,0,0,.12)'; ctx.fillRect(x + 6, yy + 6, w, h);
          ctx.drawImage(im, x, yy, w, h); ctx.strokeStyle = C.gold; ctx.lineWidth = 3; ctx.strokeRect(x, yy, w, h);
        } });
      });
    }
    const foot = (ctx, i, n, ph) => { if (ph === PH && k.footDraw) { k.footDraw(ctx, `${k.brandName()} — ${b.name} — حوالہ جات`, i, n); return; } ctx.fillStyle = C.muted; ctx.font = `20px ${FONT}`; ctx.textAlign = 'center'; ctx.fillText(`${k.brandName()} — ${b.name} — حوالہ جات${n > 1 ? ` — صفحہ ${i + 1} / ${n}` : ''}`, W / 2, ph - 92); if (k.creditDraw) k.creditDraw(ctx, W, ph); };
    const newCv = h => { const cv = document.createElement('canvas'); cv.width = W; cv.height = h; const ctx = cv.getContext('2d'); ctx.direction = 'rtl'; ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, h); return [cv, ctx]; };

    if (mode === 'poster') {
      const bl = blocks.filter(x => !x.fill);
      const Hh = bl.reduce((s, x) => s + x.h, 0) + 130;
      if (Hh > 30000) throw new Error('long');
      const [cv, ctx] = newCv(Hh); let y = 14;
      bl.forEach(x => { x.draw(ctx, y); y += x.h; });
      ctx.strokeStyle = C.gold2; ctx.lineWidth = 6; ctx.strokeRect(12, 12, W - 24, Hh - 24);
      foot(ctx, 0, 1, Hh);
      return new Promise(r => cv.toBlob(r, 'image/png'));
    }
    // PDF: صفحات
    const pages = []; let curP = [], y = TOP;
    const ROWH = 52;
    for (const x of blocks) {
      if (x.fill) {
        // اس صفحے کے آخر تک خالی سطریں
        let alt = 0; while (y + ROWH <= PH - BOT) { const r = row(0, null, alt++ % 2); curP.push(r); y += r.h; }
        continue;
      }
      if (x.page && curP.length) { pages.push(curP); curP = []; y = TOP; }
      const need = x.keep ? x.h + 60 : x.h;
      if (y + need > PH - BOT && curP.length) { pages.push(curP); curP = []; y = TOP; if (x.tbl) { curP.push(head); y += head.h; } }
      curP.push(x); y += x.h;
    }
    if (curP.length) pages.push(curP);
    const jpgs = pages.map((pg, i) => { const [cv, ctx] = newCv(PH); if (k.framePage) { k.framePage(ctx); ctx.direction = 'rtl'; } let yy = TOP; pg.forEach(x => { x.draw(ctx, yy); yy += x.h; }); foot(ctx, i, pages.length, PH); return cv.toDataURL('image/jpeg', 0.88); });
    return k.makePdf(jpgs, W, PH);
  }

  // 🖨️ خالی صفحہ — ہاتھ سے لکھ کر کتاب کے شروع میں لگانے کے لیے
  async function blankPdf(b, f, btn) {
    const k = K(); if (!k) return;
    const old = btn.innerHTML; btn.disabled = true; btn.textContent = 'بن رہا ہے…';
    try { await k.deliver(await render(b, { f, imgs: false }, 'pdf', true), `khali-safha-${b.name.slice(0, 20)}.pdf`, 'ضروری یادداشتیں — خالی صفحہ'); }
    catch (e) { console.warn(e); toast('فائل نہیں بن سکی'); }
    finally { btn.disabled = false; btn.innerHTML = old; }
  }

  // ---------- بیک اپ کے لیے ----------
  const imgIds = () => [...new Set(notes().map(n => n.img).concat((H().db().books || []).map(b => b.cover && b.cover.id)).filter(Boolean))];
  async function exportImgs() {
    const o = {};
    for (const id of imgIds()) { const b = await imgGet(id); if (b) o[id] = await blobToData(b); }
    return Object.keys(o).length ? o : undefined;
  }
  async function importImgs(o) {
    if (!o || typeof o !== 'object') return 0; let n = 0;
    for (const id of Object.keys(o)) { try { if (!(await imgHas(id))) { await imgPut(id, dataToBlob(o[id])); n++; } } catch (e) {} }
    return n;
  }
  async function removeBook(bookId) {
    const bk = (H().db().books || []).find(x => x.id === bookId); if (bk && bk.cover && bk.cover.id) await imgDel(bk.cover.id);
    const L = notes(); const gone = L.filter(n => n.book === bookId);
    for (const n of gone) if (n.img) await imgDel(n.img);
    H().db().notes = L.filter(n => n.book !== bookId);
  }

  // ===================== 📁 موضوعات — حوالہ جات کے فولڈر (ہیلپ ڈیسک #98) =====================
  function newTopic(old) {
    const name = (prompt(old ? 'موضوع کا نیا نام' : 'نئے موضوع / فولڈر کا نام لکھیں\nمثلاً: ختمِ نبوت، نماز کے مسائل، جنگِ آزادی', old ? old.name : '') || '').trim();
    if (!name) return null;
    if (old) { old.name = name; H().save(); return old; }
    const dup = topics().find(t => t.name === name); if (dup) return dup;
    const t = { id: H().newId(), name, ts: Date.now() }; topics().push(t); H().save(); return t;
  }
  function topicsRoute() {
    const tid = decodeURIComponent((location.hash.split('/')[2]) || '');
    const t = tid && topics().find(x => x.id === tid);
    if (t && location.hash.split('/')[3] === 'g') topicGallery(t, decodeURIComponent(location.hash.split('/')[4] || ''));
    else if (t) topicPage(t); else topicsList();
  }
  function topicsList() {
    const view = H().view, T = topics().slice().sort((a, b) => topicNotes(b.id).length - topicNotes(a.id).length || a.name.localeCompare(b.name, 'ur'));
    view.innerHTML = `
      <section class="panel">
        <div class="panel-h"><a class="back" href="#/">→ مکتبہ</a><h2>📁 موضوعات</h2></div>
        <div class="panel-b" id="tpb">
          <p class="nt-hint" style="margin:0 0 10px">ایک عنوان کے سب حوالے (مختلف کتب اور جلدوں سے) ایک فولڈر میں — پھر اصل صفحات کی تصاویر کے ساتھ PDF بھیجیں</p>
          <button class="btn nt-add" type="button" data-a="new" style="width:100%;justify-content:center;margin-bottom:10px">＋ نیا موضوع / فولڈر</button>
          <div class="tp-list">${T.map(t => { const L = topicNotes(t.id); return `<a class="tp-f" href="#/topics/${t.id}"><span class="ic">📁</span><span><b>${esc(t.name)}</b><small>${num(new Set(L.map(n => n.book)).size)} کتب · ${num(L.filter(n => n.img).length)} تصاویر</small></span><span class="c">${num(L.length)}</span><button type="button" class="tp-snd" data-snd="${t.id}" title="پورا موضوع بھیجیں">📤</button></a>`; }).join('') || '<div class="nt-empty"><b>ابھی کوئی موضوع نہیں</b>«نیا موضوع» بنائیں، پھر کتابوں کے حوالے اس میں جوڑیں۔</div>'}</div>
        </div>
      </section>`;
    $(view, '[data-a="new"]').onclick = () => { const t = newTopic(); if (t) location.hash = '#/topics/' + t.id; };
    // MA1911TH164: فہرست سے ہی پورا موضوع بھیجیں (ہر حوالہ، اصل صفحہ، کتاب، جلد، صفحہ نمبر)
    $(view, '#tpb').addEventListener('click', e => { const s = e.target.closest('[data-snd]'); if (!s) return; e.preventDefault(); e.stopPropagation();
      const t = topics().find(x => x.id === s.dataset.snd); if (!t) return; openSend({ id: 't_' + t.id, name: t.name, parts: 1, topic: true }, { list: topicNotes(t.id), imgs: true }); }, true);
  }
  function topicPage(t) {
    const view = H().view, L = topicNotes(t.id), pseudo = { id: 't_' + t.id, name: t.name, parts: 1, topic: true };
    view.innerHTML = `
      <section class="panel">
        <div class="panel-h"><a class="back" href="#/topics">→ موضوعات</a><span class="crumb">📁 موضوع</span></div>
        <div class="panel-b" id="tpb">
          <div class="nt-book"><b>${esc(t.name)}</b><small>${num(L.length)} حوالے · ${num(new Set(L.map(n => n.book)).size)} کتب · ${num(L.filter(n => n.img).length)} تصاویر</small></div>
          <div class="nt-acts">
            <button class="btn nt-add" type="button" data-a="pick">＋ پہلے سے لکھے حوالے اس میں جوڑیں</button>
            <button class="btn" type="button" data-a="write">✍️ نیا حوالہ لکھیں</button>
            <a class="btn nt-add" href="#/topics/${t.id}/g" style="text-decoration:none">🖼️ سب حوالے دیکھیں / چن کر بھیجیں</a>
            <button class="btn" type="button" data-a="send">${I_SHARE} بھیجیں / PDF</button>
            <button class="btn ghost" type="button" data-a="ren">✏️ نام بدلیں</button>
            <button class="btn ghost nt-del" type="button" data-a="del">🗑️ فولڈر حذف</button>
          </div>
          <div class="nt-sheet">${L.map((n, i) => { const bk = bookOf(n); return `<div class="tp-row" data-id="${n.id}"><span class="n">${num(i + 1)}</span><span class="t" data-a="edit">${esc(n.text)}<span class="r">📖 ${esc(topicRef(n))}</span></span><span class="cl">${n.img ? `<img class="nt-th" data-a="view" data-img="${n.img}" alt="تصویر">` : (bk ? `<button type="button" class="nt-clip" data-a="att" aria-label="تصویر لگائیں">${I_CLIP}</button>` : '')}<button type="button" class="x" data-a="rm" aria-label="فولڈر سے ہٹائیں">✕</button></span></div>`; }).join('') || '<div class="nt-empty"><b>اس فولڈر میں ابھی کوئی حوالہ نہیں</b>«حوالے جوڑیں» سے کسی بھی کتاب کے حوالے چنیں، یا «نیا حوالہ لکھیں»۔</div>'}</div>
          <p class="nt-hint">✕ = صرف اس فولڈر سے ہٹائیں (حوالہ کتاب میں رہتا ہے)</p>
        </div>
      </section>`;
    view.querySelectorAll('img[data-img]').forEach(async im => { const u = await imgUrl(im.dataset.img); if (u) im.src = u; else im.remove(); });
    $(view, '#tpb').addEventListener('click', e => {
      const a = e.target.closest('[data-a]'); if (!a) return;
      const row = a.closest('.tp-row'), n = row ? notes().find(x => x.id === row.dataset.id) : null, bk = n && bookOf(n);
      const k = a.dataset.a;
      if (k === 'pick') pickNotes(t);
      else if (k === 'write') pickBook(bk2 => { presetTopic = t.id; openForm(bk2, null, volOf[bk2.id] || 1); presetTopic = ''; });
      else if (k === 'send') openSend(pseudo, { list: topicNotes(t.id), imgs: true });
      else if (k === 'ren') { newTopic(t); topicPage(t); }
      else if (k === 'del') { if (!confirm(`«${t.name}» فولڈر حذف کریں؟\nحوالے اپنی کتابوں میں رہیں گے، صرف فولڈر ہٹے گا۔`)) return; const d = H().db(); d.topics = topics().filter(x => x.id !== t.id); notes().forEach(x => { if (inTopic(x, t.id)) x.topics = x.topics.filter(y => y !== t.id); }); H().save(); toast('فولڈر حذف ہو گیا'); location.hash = '#/topics'; }
      else if (k === 'rm' && n) { n.topics = n.topics.filter(y => y !== t.id); n.upd = Date.now(); H().save(); toast('فولڈر سے ہٹ گیا'); topicPage(t); }
      else if (k === 'edit' && n && bk) openForm(bk, n);
      else if (k === 'view' && n) location.hash = '#/topics/' + t.id + '/g/' + n.id;   // MA1911TH164: ایک تصویر نہیں — سب حوالے، اسی پر
      else if (k === 'att' && n && bk) quickAttach(bk, n);
    });
  }

  // ===== MA1911TH164 (مالک کا حکم): موضوع کے سب حوالے اوپر سے نیچے — ایک صفحے پر ۱ / ۲ / ۳ / ۴ حوالے؛ ✓ لگا کر چنے ہوئے اکٹھے بھیجیں (تصویر صفحات یا PDF) =====
  const GKEY = 'maktaba-aziz-tpg';
  let gSel = null, gTid = '';
  const gPer = () => { try { return Math.min(4, Math.max(1, parseInt(localStorage.getItem(GKEY), 10) || 2)); } catch (_) { return 2; } };
  function topicGallery(t, startId) {
    const view = H().view, L = topicNotes(t.id);
    if (gTid !== t.id || !gSel) { gSel = new Set(L.map(n => n.id)); gTid = t.id; }
    const per = gPer(), pages = [];
    for (let i = 0; i < L.length; i += per) pages.push(L.slice(i, i + per));
    const nSel = () => L.filter(n => gSel.has(n.id)).length;
    view.innerHTML = `
      <section class="panel">
        <div class="panel-h"><a class="back" href="#/topics/${t.id}">→ ${esc(t.name)}</a><span class="crumb">🖼️ سب حوالے</span></div>
        <div class="panel-b" id="tpg">
          <div class="nt-book"><b>${esc(t.name)}</b><small>${num(L.length)} حوالے · ${num(L.filter(n => n.img).length)} تصاویر</small></div>
          <div class="tpg-bar"><span>ایک صفحے پر:</span>${[1, 2, 3, 4].map(k => `<button type="button" class="tpg-n${k === per ? ' on' : ''}" data-per="${k}">${num(k)}</button>`).join('')}
            <button type="button" class="tpg-all" data-a="all">${nSel() === L.length ? '☐ کوئی نہیں' : '☑️ سب چنیں'}</button></div>
          <div class="tpg-send"><button class="btn save" type="button" data-a="go">📤 چنے ہوئے بھیجیں (<span id="tpgN">${num(nSel())}</span>)</button><button class="btn" type="button" data-a="pdf">📄 PDF</button></div>
          ${pages.map((P, pi) => `<div class="tpg-pg p${per}"><div class="tpg-h">صفحہ ${num(pi + 1)} / ${num(pages.length)}</div>${P.map(n => { const i = L.indexOf(n) + 1, on = gSel.has(n.id);
            return `<div class="tpg-it${on ? '' : ' off'}" id="g_${n.id}" data-id="${n.id}"><label class="tpg-ck"><input type="checkbox" ${on ? 'checked' : ''}><b>${num(i)}</b></label>
              <div class="tpg-tx">${esc(n.text)}<small>📖 ${esc(topicRef(n))}</small></div>
              ${n.img ? `<img class="tpg-im" data-img="${n.img}" alt="اصل صفحہ">` : '<div class="tpg-noim">تصویر نہیں لگی</div>'}</div>`; }).join('')}</div>`).join('') || '<div class="nt-empty"><b>اس فولڈر میں ابھی کوئی حوالہ نہیں</b></div>'}
        </div>
      </section>`;
    view.querySelectorAll('img[data-img]').forEach(async im => { const u = await imgUrl(im.dataset.img); if (u) im.src = u; else im.replaceWith(Object.assign(document.createElement('div'), { className: 'tpg-noim', textContent: 'تصویر نہیں ملی' })); });
    if (startId) setTimeout(() => { const el = document.getElementById('g_' + startId); if (el) { el.scrollIntoView({ block: 'center' }); el.classList.add('hl'); } }, 120);
    const box = $(view, '#tpg');
    box.addEventListener('change', e => { const c = e.target; if (c.type !== 'checkbox') return; const it = c.closest('.tpg-it'); c.checked ? gSel.add(it.dataset.id) : gSel.delete(it.dataset.id); it.classList.toggle('off', !c.checked); $(box, '#tpgN').textContent = num(nSel()); $(box, '[data-a="all"]').textContent = nSel() === L.length ? '☐ کوئی نہیں' : '☑️ سب چنیں'; });
    box.addEventListener('click', e => {
      const pb = e.target.closest('[data-per]'); if (pb) { try { localStorage.setItem(GKEY, pb.dataset.per); } catch (_) {} topicGallery(t); return; }
      const im = e.target.closest('.tpg-im'); if (im) { const n = notes().find(x => x.id === im.closest('.tpg-it').dataset.id), bk = n && bookOf(n); if (n && bk) viewImg(bk, n); return; }
      const a = e.target.closest('[data-a]'); if (!a) return;
      if (a.dataset.a === 'all') { if (nSel() === L.length) gSel.clear(); else L.forEach(n => gSel.add(n.id)); topicGallery(t); }
      else if (a.dataset.a === 'go' || a.dataset.a === 'pdf') galSend(t, L.filter(n => gSel.has(n.id)), per, a.dataset.a === 'pdf', a);
    });
  }
  // تصویر صفحات: فون جتنا صفحہ (1080×1920)، ہر صفحے پر ۱–۴ حوالے (۴ ہوں تو ۲×۲)، ہر حوالے کی عبارت، کتاب / جلد / صفحہ اور اصل صفحے کی تصویر
  async function galPages(t, LL, per) {
    const k = K(); if (k) await k.ready();
    const FONT = (k && k.FONT) || 'serif', W = 1080, PH = 1920, M = 36, TOPH = 120, FOOT = 60;
    const meas = document.createElement('canvas').getContext('2d');
    const out = [], all = topicNotes(t.id);
    for (let p = 0; p < LL.length; p += per) {
      const P = LL.slice(p, p + per), cv = document.createElement('canvas'); cv.width = W; cv.height = PH;
      const ctx = cv.getContext('2d'); ctx.direction = 'rtl';
      ctx.fillStyle = '#fffaf0'; ctx.fillRect(0, 0, W, PH);
      ctx.fillStyle = '#14532d'; ctx.fillRect(0, 0, W, TOPH);
      ctx.fillStyle = '#fde68a'; ctx.textAlign = 'center'; ctx.font = `48px ${FONT}`; ctx.fillText(k ? k.fit(ctx, '📁 ' + t.name, W - 80) : t.name, W / 2, 74);
      ctx.fillStyle = '#f3e6c2'; ctx.font = `22px ${FONT}`; ctx.fillText(`صفحہ ${p / per + 1} / ${Math.ceil(LL.length / per)}`, W / 2, 108);
      const cols = per === 4 ? 2 : 1, rows = per === 4 ? 2 : per, gap = 16;
      const cw = (W - 2 * M - (cols - 1) * gap) / cols, ch = (PH - TOPH - FOOT - 2 * gap - (rows - 1) * gap) / rows;
      for (let j = 0; j < P.length; j++) {
        const n = P[j], cx = W - M - (j % cols + 1) * cw - (j % cols) * gap, cy = TOPH + gap + Math.floor(j / cols) * (ch + gap);
        ctx.fillStyle = '#ffffff'; ctx.strokeStyle = '#c8962f'; ctx.lineWidth = 3; if (k && k.roundRect) { k.roundRect(ctx, cx, cy, cw, ch, 18); ctx.fill(); ctx.stroke(); } else { ctx.fillRect(cx, cy, cw, ch); ctx.strokeRect(cx, cy, cw, ch); }
        const fs = per === 1 ? 34 : per === 2 ? 30 : 26, lh = fs * 1.55, tw = cw - 40;
        meas.font = `${fs}px ${FONT}`;
        let lines = wrapLines(meas, `${all.indexOf(n) + 1}۔ ${n.text}`, tw); const maxL = per === 1 ? 6 : per === 2 ? 4 : 3;
        if (lines.length > maxL) { lines = lines.slice(0, maxL); lines[maxL - 1] += ' …'; }
        meas.font = `${fs - 4}px ${FONT}`; const rl = wrapLines(meas, '📖 ' + topicRef(n), tw).slice(0, 2);
        let y = cy + 14 + fs * 1.2; ctx.textAlign = 'right';
        ctx.fillStyle = '#1f2937'; ctx.font = `${fs}px ${FONT}`; lines.forEach(l => { ctx.fillText(l, cx + cw - 20, y); y += lh; });
        ctx.fillStyle = '#8a5f16'; ctx.font = `${fs - 4}px ${FONT}`; rl.forEach(l => { ctx.fillText(l, cx + cw - 20, y); y += lh * .9; });
        const iy = y - fs * .4, ih = cy + ch - 14 - iy, iw = cw - 28;
        if (n.img && ih > 60) { try { const u = await imgUrl(n.img); if (u) { const im = await loadImg(u), r = Math.min(iw / im.width, ih / im.height), w = im.width * r, h = im.height * r; ctx.drawImage(im, cx + 14 + (iw - w) / 2, iy + (ih - h) / 2, w, h); } } catch (_) {} }
      }
      ctx.fillStyle = '#14532d'; ctx.fillRect(0, PH - FOOT, W, FOOT); ctx.fillStyle = '#fde68a'; ctx.textAlign = 'center'; ctx.font = `26px ${FONT}`;
      try { ctx.fillText(k && k.brandName ? k.brandName() : 'میرا مکتبہ', W / 2, PH - 20); } catch (_) {}
      out.push(cv.toDataURL('image/jpeg', 0.88));
    }
    return out;
  }
  async function galSend(t, LL, per, pdf, btn) {
    if (!LL.length) { toast('پہلے ✓ لگا کر حوالے چنیں'); return; }
    const old = btn.innerHTML; btn.disabled = true; btn.textContent = 'تیار ہو رہا ہے…';
    try {
      const urls = await galPages(t, LL, per), k = K(), nm = String(t.name).replace(/[^\w؀-ۿ]+/g, '-').slice(0, 30) || 'mozoo';
      if (pdf && k) { await k.deliver(k.makePdf(urls, 1080, 1920), `${nm}.pdf`, t.name); return; }
      const files = urls.map((u, i) => new File([dataToBlob(u)], `${nm}-${i + 1}.jpg`, { type: 'image/jpeg' }));
      if (navigator.canShare && navigator.canShare({ files })) { try { await navigator.share({ files, text: `📁 ${t.name}` }); return; } catch (x) { if (x && x.name === 'AbortError') return; } }
      for (const f of files) { if (k) await k.deliver(f, f.name, t.name); }
    } catch (e) { toast('بھیجنے میں مسئلہ — دوبارہ کوشش کریں'); }
    finally { btn.disabled = false; btn.innerHTML = old; }
  }
  // کسی بھی کتاب کے حوالے تلاش کر کے فولڈر میں
  function pickNotes(t) {
    const { wrap, close } = H().openSheet(`«${t.name}» میں حوالے جوڑیں`, `
      <div class="sheet-b nt-so">
        <input class="search" id="tpQ" type="search" placeholder="عبارت، کتاب، صفحہ… تلاش کریں" autocomplete="off">
        <div class="tp-pk" id="tpPk"></div>
        <button class="btn save" type="button" id="tpOk">✅ جوڑیں</button>
      </div>`);
    const chosen = new Set(topicNotes(t.id).map(n => n.id));
    const draw = () => {
      const w = String($(wrap, '#tpQ').value || '').trim().split(/\s+/).filter(Boolean);
      const L = notes().filter(n => bookOf(n)).filter(n => !w.length || w.every(x => (n.text + ' ' + topicRef(n)).includes(x)));
      $(wrap, '#tpPk').innerHTML = L.slice(0, 300).map(n => `<label><input type="checkbox" value="${n.id}" ${chosen.has(n.id) ? 'checked' : ''}><span>${esc(n.text)}<small>📖 ${esc(topicRef(n))}${n.img ? ' · 🖼️' : ''}</small></span></label>`).join('') || '<p class="sh-empty">کوئی حوالہ نہیں ملا — پہلے کسی کتاب کے «حوالہ جات» میں لکھیں</p>';
    };
    draw();
    $(wrap, '#tpQ').addEventListener('input', draw);
    $(wrap, '#tpPk').addEventListener('change', e => { const c = e.target; if (c.type === 'checkbox') c.checked ? chosen.add(c.value) : chosen.delete(c.value); });
    $(wrap, '#tpOk').onclick = () => {
      let add = 0;
      notes().forEach(n => {
        const has = inTopic(n, t.id);
        if (chosen.has(n.id) && !has) { n.topics = (n.topics || []).concat(t.id); n.tord = Date.now() + add; add++; }
        else if (!chosen.has(n.id) && has) n.topics = n.topics.filter(y => y !== t.id);
      });
      H().save(); close(); toast(`فولڈر میں ${num(topicNotes(t.id).length)} حوالے`); topicPage(t);
    };
  }
  function pickBook(cb) {
    const { wrap, close } = H().openSheet('کس کتاب کا حوالہ؟', `
      <div class="sheet-b nt-so"><input class="search" id="tbQ" type="search" placeholder="کتاب یا مصنف…" autocomplete="off"><div class="tp-pk" id="tbL"></div></div>`);
    const draw = () => {
      const q = String($(wrap, '#tbQ').value || '').trim();
      const B = (H().db().books || []).filter(b => !q || [b.name, b.author].some(v => (v || '').includes(q)));
      $(wrap, '#tbL').innerHTML = B.slice(0, 200).map(b => `<button type="button" class="btn ghost" data-b="${b.id}" style="justify-content:flex-start">📖 ${esc(b.name)}${b.author ? ` <small>· ${esc(b.author)}</small>` : ''}</button>`).join('') || '<p class="sh-empty">کوئی کتاب نہیں ملی</p>';
    };
    draw(); $(wrap, '#tbQ').addEventListener('input', draw);
    $(wrap, '#tbL').addEventListener('click', e => { const x = e.target.closest('[data-b]'); if (!x) return; const b = (H().db().books || []).find(y => y.id === x.dataset.b); close(); if (b) setTimeout(() => cb(b), 80); });
  }
  const topicCount = () => topics().length;

  window.MA_NOTES = { page, topicsRoute, topicCount, countOf, imgIds, imgGet, imgPut, imgHas, imgDel, imgUrl, exportImgs, importImgs, removeBook, _test: { render, textOf } };
  // ایپ پہلے کھل چکی ہو تو صفحہ دوبارہ بنائیں (یادداشتوں کا صفحہ / گنتی)
  if (window.MA_APP && /\/b\/|^#\/topics/.test(location.hash)) window.MA_APP.route();
})();
